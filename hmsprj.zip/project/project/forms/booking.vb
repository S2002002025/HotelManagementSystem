﻿Imports MySql.Data.MySqlClient
Public Class booking
    Dim SqlConn, sqlConna As New MySqlConnection
    Dim sqlCmd, sqlCmda As New MySqlCommand
    Dim sqlRd, sqlRda As MySqlDataReader
    Dim sqldt, sqldta As New DataTable
    Dim Dta, Dtaa As New MySqlDataAdapter
    Dim SqlQuery, SqlQuerya As String
    Dim server As String = "localhost"
    Dim user As String = "root"
    Dim password As String = ""
    Dim database As String = "projectdb"

    Private Sub updatetablea()
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            sqlCmd.CommandText = "SELECT * FROM room where room.guestid=0"
            sqlRd = sqlCmd.ExecuteReader
            sqldt.Load(sqlRd)
            sqlRd.Close()
            SqlConn.Close()
            DataGridView2.DataSource = sqldt
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub

    Private Sub DataGridView2_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellClick
        Try
            Guna2TextBox2.Text = DataGridView2.SelectedRows(0).Cells(0).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        Try
            Guna2TextBox1.Text = DataGridView1.SelectedRows(0).Cells(0).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub updatetableb()
        Try
            sqlConna.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            sqlConna.Open()
            sqlCmda.Connection = sqlConna
            sqlCmda.CommandText = "SELECT * FROM guest"
            sqlRda = sqlCmda.ExecuteReader
            sqldta.Load(sqlRda)
            sqlRda.Close()
            sqlConna.Close()
            DataGridView1.DataSource = sqldta
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            sqlConna.Close()
        End Try
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Close()
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        updatetablea()
        updatetableb()

    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        Guna2TextBox1.Clear()
        Guna2TextBox2.Clear()
    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            With sqlCmd
                ' Update room SET room.guestid = '8' WHERE roomid = '4'
                .CommandText = "Update room SET room.guestid = '@guestid' WHERE roomid = '@roomid'"
                .CommandType = CommandType.Text
                .Parameters.AddWithValue("@roomid", Guna2TextBox2.Text)
                .Parameters.AddWithValue("@guestid", Guna2TextBox1.Text)
            End With
            sqlCmd.ExecuteNonQuery()
            SqlConn.Close()
            MessageBox.Show("Room booked", "Booking Update", MessageBoxButtons.OK)
            updatetablea()
            updatetableb()
            SqlConn.Close()
        Catch ex As Exception
            SqlConn.Close()
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try

        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            SqlQuery = "INSERT INTO booking(guestid,roomid,date)VALUES ('" & Guna2TextBox1.Text & "' ,'" & Guna2TextBox2.Text & "' ,' @date ')"
            sqlCmd.Parameters.AddWithValue("@date", Guna2DateTimePicker1.Value)
            sqlCmd = New MySqlCommand(SqlQuery, SqlConn)
            sqlRd = sqlCmd.ExecuteReader
            SqlConn.Close()
            MessageBox.Show("Booking Recorded", "Data Insertion", MessageBoxButtons.OK)

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK,
            MessageBoxIcon.Information)
            SqlConn.Close()
        End Try

    End Sub


End Class