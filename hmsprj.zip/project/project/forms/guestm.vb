﻿Imports MySql.Data.MySqlClient
Public Class guestm
    Dim SqlConn As New MySqlConnection
    Dim sqlCmd As New MySqlCommand
    Dim sqlRd As MySqlDataReader
    Dim sqldt As New DataTable
    Dim Dta As New MySqlDataAdapter
    Dim SqlQuery As String
    Dim server As String = "localhost"
    Dim user As String = "root"
    Dim password As String = ""
    Dim database As String = "projectdb"

    Private Sub updatetable()
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            sqlCmd.CommandText = "SELECT * FROM guest"
            sqlRd = sqlCmd.ExecuteReader
            sqldt.Load(sqlRd)
            sqlRd.Close()
            SqlConn.Close()
            DataGridView1.DataSource = sqldt
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            SqlQuery = "INSERT INTO guest(guestid,name,address,mobileno,gender,peopleno)VALUES ('" & Guna2TextBox1.Text & "' ,'" & Guna2TextBox2.Text & "' , '" & Guna2TextBox3.Text & "','" & Guna2TextBox4.Text & "', '" & Guna2TextBox5.Text & "','" & Guna2TextBox6.Text & "')"
            sqlCmd = New MySqlCommand(SqlQuery, SqlConn)
            sqlRd = sqlCmd.ExecuteReader
            SqlConn.Close()
            MessageBox.Show("Data of guest Inserted", "Data Insertion", MessageBoxButtons.OK)
            updatetable()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK,
            MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        updatetable()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            With sqlCmd
                '.CommandText = "UPDATE guest set guestid = @guestid,address=@address,mobileno=@mobileno,gender=@gender WHERE guestid = @guestid"
                .CommandText = "Update `guest` Set 'name'=;@name', `address` = '@address', `mobileno` = '@mobileno', `gender` = '@gender','peopleno'='@peopleno' WHERE `guest`.`guestid` = '@guestid'"
                .CommandType = CommandType.Text
                .Parameters.AddWithValue("@guestid", Guna2TextBox1.Text)
                .Parameters.AddWithValue("@name", Guna2TextBox2.Text)
                .Parameters.AddWithValue("@address", Guna2TextBox3.Text)
                .Parameters.AddWithValue("@mobileno", Guna2TextBox4.Text)
                .Parameters.AddWithValue("@gender", Guna2TextBox5.Text)
                .Parameters.AddWithValue("@peopleno", Guna2TextBox6)
            End With
            sqlCmd.ExecuteNonQuery()
            SqlConn.Close()
            MessageBox.Show("Data Updated", "Data Update", MessageBoxButtons.OK)
            updatetable()
        Catch ex As Exception
            SqlConn.Close()
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim iexit As DialogResult
        iexit = MessageBox.Show("Confirm If you want to Delete", "Food Management", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If iexit = DialogResult.Yes Then
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            sqlCmd.CommandText = "DELETE FROM guest where guestid= '" & Guna2TextBox1.Text & "'"
            sqlRd = sqlCmd.ExecuteReader
            SqlConn.Close()
            MessageBox.Show("Data Deleted", "guest management", MessageBoxButtons.OK)
            For Each row As DataGridViewRow In DataGridView1.SelectedRows
                DataGridView1.Rows.Remove(row)
            Next
        End If
        updatetable()
    End Sub


    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try

            Guna2TextBox1.Text = DataGridView1.SelectedRows(0).Cells(0).Value.ToString
            Guna2TextBox2.Text = DataGridView1.SelectedRows(0).Cells(1).Value.ToString
            Guna2TextBox3.Text = DataGridView1.SelectedRows(0).Cells(2).Value.ToString
            Guna2TextBox4.Text = DataGridView1.SelectedRows(0).Cells(3).Value.ToString
            Guna2TextBox5.Text = DataGridView1.SelectedRows(0).Cells(4).Value.ToString
            Guna2TextBox6.Text = DataGridView1.SelectedRows(0).Cells(5).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub guestm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Guna2TextBox5_TextChanged(sender As Object, e As EventArgs) Handles Guna2TextBox5.TextChanged

    End Sub
End Class