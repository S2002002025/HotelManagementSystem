﻿Imports MySql.Data.MySqlClient
Public Class login
    Dim sqlconn As New MySqlConnection
    Dim sqlcmd As New MySqlCommand
    Dim sqlrd As MySqlDataReader
    Dim sqldt As New DataTable
    Dim dta As New MySqlDataAdapter
    Dim sqlquery As String

    Dim server As String = "localhost"
    Dim user As String = "root"
    Dim password As String = ""
    Dim database As String = "projectdb"

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Guna2TextBox1.Clear()
        Guna2TextBox2.Clear()
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (Guna2TextBox1.Text = "") Then
            MsgBox("Enter USERNAME")
            Guna2TextBox1.Focus()
            Exit Sub
        ElseIf (Guna2TextBox2.Text = "") Then
            MsgBox("Enter PASSWORD")
            Guna2TextBox2.Focus()
            Exit Sub
        ElseIf (guna2textbox1.Text = "meadmin" And Guna2TextBox2.Text = "it'sme") Then
            adminhome.Show()
            Me.Hide()
            Guna2TextBox1.Clear()
            Guna2TextBox2.Clear()
        Else
            Try
                sqlconn.Open()
                Dim Query As String
                Query = "select * from projectdb.login where username='" & Guna2TextBox1.Text & "' and password='" & Guna2TextBox1.Text & "' "
                sqlcmd = New MySqlCommand(Query, sqlconn)
                sqlrd = sqlcmd.ExecuteReader
                Dim count As Integer
                count = 0
                While sqlrd.Read
                    count = count + 1

                End While

                If count = 1 Then
                    userhome.Show()
                    Me.Hide()
                    Guna2TextBox1.Clear()
                    Guna2TextBox2.Clear()
                ElseIf count > 1 Then
                    MessageBox.Show("Username and password are Duplicate")
                    Guna2TextBox1.Clear()
                    Guna2TextBox2.Clear()
                Else
                    MessageBox.Show("Username and password are not correct")
                    Guna2TextBox1.Clear()
                    Guna2TextBox2.Clear()
                End If

                sqlconn.Close()
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)
            Finally
                sqlconn.Dispose()
            End Try
        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        sqlconn.ConnectionString = "server=" + server + ";" + "user=" + user + ";" + "password=" + password + ";" + "database=" + database
        Try
            sqlconn.Open()
            MessageBox.Show("Connection Successful")
            sqlconn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            sqlconn.Dispose()

        End Try


    End Sub


End Class