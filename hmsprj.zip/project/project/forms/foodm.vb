﻿Imports MySql.Data.MySqlClient
Public Class foodm
    Dim SqlConn As New MySqlConnection
    Dim sqlCmd As New MySqlCommand
    Dim sqlRd As MySqlDataReader
    Dim sqldt As New DataTable
    Dim Dta As New MySqlDataAdapter
    Dim SqlQuery As String
    Dim server As String = "localhost"
    Dim user As String = "root"
    Dim password As String = ""
    Dim database As String = "projectdb"

    Private Sub updatetable()
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            sqlCmd.CommandText = "SELECT * FROM menu"
            sqlRd = sqlCmd.ExecuteReader
            sqldt.Load(sqlRd)
            sqlRd.Close()
            SqlConn.Close()
            DataGridView1.DataSource = sqldt
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        updatetable()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            SqlQuery = "INSERT INTO menu(foodid,foodname,price,foodtype)VALUES ('" & Guna2TextBox4.Text & "' ,'" & Guna2TextBox1.Text & "' , '" & Guna2TextBox2.Text & "','" & Guna2TextBox3.Text & "')"
            sqlCmd = New MySqlCommand(SqlQuery, SqlConn)
            sqlRd = sqlCmd.ExecuteReader
            SqlConn.Close()
            MessageBox.Show("Data food Inserted", "Data Insertion", MessageBoxButtons.OK)
            updatetable()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub

    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        Me.Close()
        adminhome.Show()
    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click

        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            With sqlCmd
                '.CommandText = "UPDATE menu set foodid = @foodid,foodname=@foodname,price=@price,foodtype=@foodtype WHERE foodid = @foodid"
                .CommandText = "Update `menu` Set `foodname` = '@foodname', `price` = '@price', `foodtype` = '@foodtype' WHERE `menu`.`foodid` = '@foodid'"
                .CommandType = CommandType.Text
                .Parameters.AddWithValue("@foodid", Guna2TextBox4.Text)
                .Parameters.AddWithValue("@foodname", Guna2TextBox1.Text)
                .Parameters.AddWithValue("@price", Guna2TextBox2.Text)
                .Parameters.AddWithValue("@foodtype", Guna2TextBox3.Text)
            End With
            sqlCmd.ExecuteNonQuery()
            SqlConn.Close()
            MessageBox.Show("Data Updated", "Data Update", MessageBoxButtons.OK)
            updatetable()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub


    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        Dim iexit As DialogResult
        iexit = MessageBox.Show("Confirm If you want to Delete", "Food Management", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If iexit = DialogResult.Yes Then
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            sqlCmd.CommandText = "DELETE FROM menu where foodid= '" & Guna2TextBox4.Text & "'"
            sqlRd = sqlCmd.ExecuteReader
            SqlConn.Close()
            MessageBox.Show("Data Deleted", "CRUD Application", MessageBoxButtons.OK)
            For Each row As DataGridViewRow In DataGridView1.SelectedRows
                DataGridView1.Rows.Remove(row)
            Next
        End If
        updatetable()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try

            Guna2TextBox4.Text = DataGridView1.SelectedRows(0).Cells(0).Value.ToString
            Guna2TextBox1.Text = DataGridView1.SelectedRows(0).Cells(1).Value.ToString
            Guna2TextBox2.Text = DataGridView1.SelectedRows(0).Cells(2).Value.ToString
            Guna2TextBox3.Text = DataGridView1.SelectedRows(0).Cells(3).Value.ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub foodm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class