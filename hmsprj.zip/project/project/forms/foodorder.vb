﻿Imports MySql.Data.MySqlClient
Public Class foodorder
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Close()
    End Sub


    Dim SqlConn, sqlConna, sqlConnb As New MySqlConnection
    Dim sqlCmd, sqlCmda, sqlCmdb As New MySqlCommand
    Dim sqlRd, sqlRda, sqlRdb As MySqlDataReader
    Dim sqldt, sqldta, sqldtb As New DataTable
    Dim Dta, Dtaa, Dtab As New MySqlDataAdapter
    Dim SqlQuery, SqlQuerya, SqlQueryb As String

    Private Sub Guna2DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Guna2DataGridView1.CellClick
        Try
            Guna2TextBox1.Text = Guna2DataGridView1.SelectedRows(0).Cells(0).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Guna2DataGridView2_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Guna2DataGridView2.CellClick
        Try
            Guna2TextBox2.Text = Guna2DataGridView2.SelectedRows(0).Cells(0).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            SqlQuery = "INSERT INTO orders(roomid,tableno,foodid)VALUES ('" & Guna2TextBox1.Text & "' ,'" & Guna2TextBox2.Text & "' , '" & Guna2TextBox3.Text & "')"
            sqlCmd = New MySqlCommand(SqlQuery, SqlConn)
            sqlRd = sqlCmd.ExecuteReader
            SqlConn.Close()
            MessageBox.Show("Food ordered", "Ordering", MessageBoxButtons.OK)
            Guna2TextBox1.Clear()
            Guna2TextBox2.Clear()
            Guna2TextBox3.Clear()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK,
            MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub

    Private Sub Guna2DataGridView3_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Guna2DataGridView3.CellClick
        Try
            Guna2TextBox3.Text = Guna2DataGridView3.SelectedRows(0).Cells(0).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Dim server As String = "localhost"
    Dim user As String = "root"
    Dim password As String = ""
    Dim database As String = "projectdb"

    Private Sub updatetablemenu()
        Try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
            sqlCmd.CommandText = "SELECT * FROM menu"
            sqlRd = sqlCmd.ExecuteReader
            sqldt.Load(sqlRd)
            sqlRd.Close()
            SqlConn.Close()
            Guna2DataGridView3.DataSource = sqldt
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            SqlConn.Close()
        End Try
    End Sub

    Private Sub updatetableroom()
        Try
            sqlConna.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            sqlConna.Open()
            sqlCmda.Connection = sqlConna
            sqlCmda.CommandText = "SELECT * FROM room where room.guestid != '0'"
            sqlRda = sqlCmda.ExecuteReader
            sqldta.Load(sqlRda)
            sqlRda.Close()
            sqlConna.Close()
            Guna2DataGridView1.DataSource = sqldta
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            sqlConna.Close()
        End Try
    End Sub


    Private Sub updatetablet()
        Try
            sqlConnb.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            sqlConnb.Open()
            sqlCmdb.Connection = sqlConnb
            sqlCmdb.CommandText = "SELECT * FROM tables "
            sqlRdb = sqlCmdb.ExecuteReader
            sqldtb.Load(sqlRdb)
            sqlRdb.Close()
            sqlConnb.Close()
            Guna2DataGridView2.DataSource = sqldtb
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            sqlConnb.Close()
        End Try
    End Sub



    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        updatetablemenu()
    End Sub

    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        updatetableroom()
    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        updatetablet()
    End Sub

    Private Sub foodorder_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class