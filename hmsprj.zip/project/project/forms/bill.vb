﻿Imports MySql.Data.MySqlClient
Public Class bill
    Dim SqlConn As New MySqlConnection
    Dim sqlCmd As New MySqlCommand
    Dim sqlRd As MySqlDataReader
    Dim sqldt As New DataTable
    Dim Dta As New MySqlDataAdapter
    Dim SqlQuery As String
    Dim server As String = "localhost"
    Dim user As String = "root"
    Dim password As String = ""
    Dim database As String = "projectdb"
    Dim billno As Integer
    Sub getuserdata()
        If Guna2TextBox2.Text = "" Then
            try
            SqlConn.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            SqlConn.Open()
            sqlCmd.Connection = SqlConn
                sqlCmd.CommandText = "SELECT guestid FROM booking Where roomid='" & Guna2TextBox2.Text & "' "
                sqlRd = sqlCmd.ExecuteReader
                sqldt.Load(sqlRd)
                sqlRd.Close()
                SqlConn.Close()
                Guna2TextBox4.Text = "sqldt"
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            SqlConn.Close()
            End Try

        End If
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        getuserdata()
    End Sub
End Class