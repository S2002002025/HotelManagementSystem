﻿Imports MySql.Data.MySqlClient
Public Class checkout
    Dim SqlConn, sqlConna, sqlConnb As New MySqlConnection
    Dim sqlCmd, sqlCmda, sqlCmdb As New MySqlCommand
    Dim sqlRd, sqlRda, sqlRdb As MySqlDataReader
    Dim sqldt, sqldta, sqldtb As New DataTable
    Dim Dta, Dtaa, Dtab As New MySqlDataAdapter


    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        updatetableroom()
    End Sub



    Private Sub Guna2DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Guna2DataGridView1.CellClick
        Try
            Guna2TextBox1.Text = Guna2DataGridView1.SelectedRows(0).Cells(0).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Guna2CircleButton2_Click(sender As Object, e As EventArgs) Handles Guna2CircleButton2.Click
        bill.Show()
    End Sub

    Private Sub Guna2DataGridView2_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Guna2DataGridView2.CellClick
        Try
            Guna2TextBox2.Text = Guna2DataGridView2.SelectedRows(0).Cells(0).Value.ToString

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click

        updatetablet()
    End Sub

    Dim SqlQuery, SqlQuerya, SqlQueryb As String
    Dim server As String = "localhost"
    Dim user As String = "root"
    Dim password As String = ""
    Dim database As String = "projectdb"
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Close()
    End Sub
    Private Sub updatetableroom()
        Try
            sqlConna.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            sqlConna.Open()
            sqlCmda.Connection = sqlConna
            sqlCmda.CommandText = "SELECT roomid FROM booking where guestid != '0'"
            sqlRda = sqlCmda.ExecuteReader
            sqldta.Load(sqlRda)
            sqlRda.Close()
            sqlConna.Close()
            Guna2DataGridView1.DataSource = sqldta
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            sqlConna.Close()
        End Try
    End Sub
    Private Sub updatetablet()
        Try
            sqlConnb.ConnectionString = "server=" + server + ";" + " user =" + user + ";" + "password=" + password + ";" + "database=" + database
            sqlConnb.Open()
            sqlCmdb.Connection = sqlConnb
            sqlCmdb.CommandText = "SELECT * FROM tables "
            sqlRdb = sqlCmdb.ExecuteReader
            sqldtb.Load(sqlRdb)
            sqlRdb.Close()
            sqlConnb.Close()
            Guna2DataGridView2.DataSource = sqldtb
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mysql Connector", MessageBoxButtons.OK, MessageBoxIcon.Information)
            sqlConnb.Close()
        End Try
    End Sub



End Class