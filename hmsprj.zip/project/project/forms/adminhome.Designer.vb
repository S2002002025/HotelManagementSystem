﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class adminhome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2CircleButton1 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2CircleButton2 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2CircleButton3 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2CircleButton5 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2CircleButton6 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2CircleButton4 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2CircleButton7 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2CircleButton8 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.SuspendLayout()
        '
        'Guna2CircleButton1
        '
        Me.Guna2CircleButton1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton1.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton1.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton1.Location = New System.Drawing.Point(31, 19)
        Me.Guna2CircleButton1.Name = "Guna2CircleButton1"
        Me.Guna2CircleButton1.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton1.Size = New System.Drawing.Size(161, 77)
        Me.Guna2CircleButton1.TabIndex = 0
        Me.Guna2CircleButton1.Text = "Food Management"
        '
        'Guna2CircleButton2
        '
        Me.Guna2CircleButton2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton2.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton2.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton2.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton2.Location = New System.Drawing.Point(31, 102)
        Me.Guna2CircleButton2.Name = "Guna2CircleButton2"
        Me.Guna2CircleButton2.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton2.Size = New System.Drawing.Size(161, 77)
        Me.Guna2CircleButton2.TabIndex = 0
        Me.Guna2CircleButton2.Text = "Room Management"
        '
        'Guna2CircleButton3
        '
        Me.Guna2CircleButton3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton3.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton3.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton3.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton3.Location = New System.Drawing.Point(31, 185)
        Me.Guna2CircleButton3.Name = "Guna2CircleButton3"
        Me.Guna2CircleButton3.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton3.Size = New System.Drawing.Size(161, 77)
        Me.Guna2CircleButton3.TabIndex = 0
        Me.Guna2CircleButton3.Text = "Guest Management"
        '
        'Guna2CircleButton5
        '
        Me.Guna2CircleButton5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton5.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton5.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton5.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton5.Location = New System.Drawing.Point(31, 351)
        Me.Guna2CircleButton5.Name = "Guna2CircleButton5"
        Me.Guna2CircleButton5.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton5.Size = New System.Drawing.Size(161, 77)
        Me.Guna2CircleButton5.TabIndex = 0
        Me.Guna2CircleButton5.Text = "Food Order"
        '
        'Guna2CircleButton6
        '
        Me.Guna2CircleButton6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton6.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton6.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton6.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton6.Location = New System.Drawing.Point(31, 434)
        Me.Guna2CircleButton6.Name = "Guna2CircleButton6"
        Me.Guna2CircleButton6.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton6.Size = New System.Drawing.Size(161, 77)
        Me.Guna2CircleButton6.TabIndex = 0
        Me.Guna2CircleButton6.Text = "Checkout"
        '
        'Guna2CircleButton4
        '
        Me.Guna2CircleButton4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton4.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton4.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton4.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton4.Location = New System.Drawing.Point(31, 268)
        Me.Guna2CircleButton4.Name = "Guna2CircleButton4"
        Me.Guna2CircleButton4.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton4.Size = New System.Drawing.Size(162, 77)
        Me.Guna2CircleButton4.TabIndex = 0
        Me.Guna2CircleButton4.Text = "Booking"
        '
        'Guna2CircleButton7
        '
        Me.Guna2CircleButton7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton7.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton7.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton7.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton7.Location = New System.Drawing.Point(31, 517)
        Me.Guna2CircleButton7.Name = "Guna2CircleButton7"
        Me.Guna2CircleButton7.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton7.Size = New System.Drawing.Size(166, 77)
        Me.Guna2CircleButton7.TabIndex = 0
        Me.Guna2CircleButton7.Text = "Report"
        '
        'Guna2CircleButton8
        '
        Me.Guna2CircleButton8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton8.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton8.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton8.FillColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2CircleButton8.Font = New System.Drawing.Font("Segoe UI", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2CircleButton8.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton8.Location = New System.Drawing.Point(617, 536)
        Me.Guna2CircleButton8.Name = "Guna2CircleButton8"
        Me.Guna2CircleButton8.ShadowDecoration.BorderRadius = 8
        Me.Guna2CircleButton8.Size = New System.Drawing.Size(166, 77)
        Me.Guna2CircleButton8.TabIndex = 0
        Me.Guna2CircleButton8.Text = "Logout"
        '
        'adminhome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.project.My.Resources.Resources.adminhomebg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(795, 625)
        Me.Controls.Add(Me.Guna2CircleButton8)
        Me.Controls.Add(Me.Guna2CircleButton7)
        Me.Controls.Add(Me.Guna2CircleButton6)
        Me.Controls.Add(Me.Guna2CircleButton3)
        Me.Controls.Add(Me.Guna2CircleButton5)
        Me.Controls.Add(Me.Guna2CircleButton4)
        Me.Controls.Add(Me.Guna2CircleButton2)
        Me.Controls.Add(Me.Guna2CircleButton1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "adminhome"
        Me.Text = "adminhome"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2CircleButton1 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton2 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton3 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton5 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton6 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton4 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton7 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton8 As Guna.UI2.WinForms.Guna2CircleButton
End Class
